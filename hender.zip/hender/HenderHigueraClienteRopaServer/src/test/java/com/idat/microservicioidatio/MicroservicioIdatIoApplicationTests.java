package com.idat.microservicioidatio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioIdatIoApplicationTests {

    @Test
    void contextLoads() {
    }

}
